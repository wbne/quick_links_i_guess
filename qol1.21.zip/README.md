# quick_links_i_guess
extension I used to keep class zoom links up during the pandemic season

firefox store page: https://addons.mozilla.org/en-US/firefox/addon/quick-links-i-guess/
